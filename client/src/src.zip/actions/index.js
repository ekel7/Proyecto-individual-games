import axios from 'axios';
export const search_Game = 'SEARCH_GAME';
export const show_Games = 'SEARCH_GAMES';

export const searchGame = (searchQuery) => async (dispatch)=> {
        try{
            let result = await axios.get('http://localhost:3001/videogames/search?'+ searchQuery)
            let data = result.data;
            console.log('action searchGame llamada. datos: '+data)
            dispatch({
                type: search_Game,
                payload: data,
            })
        }catch(err){
            console.error(err)
        }
        
        
    }

export const showGames = () => async (dispatch) => {
        try{
            let result = await axios.get('http://localhost:3001/videogames/')
            let data = result.data;
            console.log('action showGames llamada. datos: '+data)
            console.log(data)
            dispatch({
                type: show_Games,
                payload: data,
            })
        }catch(err){
            console.log(err)
        }
        
    }
