import React from 'react'
import styled from 'styled-components'

function GameCard() {
    const Button = styled.button`
        background: transparent;
        border-radius: 3px;
        border: 2px solid palevioletred;
        color: white;
        margin: 0 1em;
        padding: 0.25em 1em;
    `
    return (
        <div className='card__Container'>
            <Button
                'I'm a button!'
            />
            
        </div>
    )
}

export default GameCard;
