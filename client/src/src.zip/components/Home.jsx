import React,{ useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { Link } from 'react-router-dom'
import { showGames, searchGame } from '../actions/index'
import GameCard from './GameCard';
import '../styles/Home.css'

export function Home(){
    const [input, setInput] = useState({
        name: ''
    })

    
    const dispatch = useDispatch();

    const Games = useSelector((state) => state.loadedGames)

    function handleChange(e){
        console.log('handleChange funcionando')
        setInput({
            ...input,
            name: e.target.value
        })
    }

    function handleSubmit(e){
        e.preventDefault();
        console.log('handleSubmit llamado')
        dispatch(searchGame(e.target.value))
    }

    useEffect(() => {
        dispatch(showGames())    
    }, [])

    console.log(Games)
    const { name } = input;
    return(
        
        <div className='home__Wrapper'>
            <h4>Búsqueda de videojuegos</h4>
                <form className='form-container' onSubmit={(e) => handleSubmit}>
                    <div>
                        <label className='label' htmlFor='title'>Juego:</label>
                       <input
                            type='text'
                            id='title'
                            placeholder='Busca un juego...'
                            value={ name }
                            autoComplete='off'
                            onChange={(e) => handleChange(e)}
                        />
                    </div>
                    <button type='submit'>Buscar</button>
                </form>
            <GameCard/>

        </div>
    )
}  