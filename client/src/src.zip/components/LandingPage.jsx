import React from 'react';
import Router from 'react-router-dom';
import '../styles/LandingPage.css';

export function LandingPage(){
    return (
        <div className='landing__Wrapper'>
            <h4>
                Bienvenido al proyecto Videogames!
            </h4>
        </div>
    )
}