import { search_Game, show_Games } from '../actions/index'

const initialState = {
    currentGameId: '',
    loadedGames: [],
    gameDetail:{}
}

function rootReducer(state = initialState, action) {
    if(action.type === search_Game){
        console.log('Reducer searchGame')
        return{
            ...state,
            loadedGames:action.payload
        }
    }
    if(action.type === show_Games){
        console.log('Reducer showGames')
        return{
            ...state,
            loadedGames: action.payload
        }
    }
    return state;
}



export default rootReducer;